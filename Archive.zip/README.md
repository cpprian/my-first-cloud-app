repo: https://github.com/cpprian/my-first-cloud-app

cloud platform: Google Cloud Platform

# How to run app
1. Build the docker image with `docker build -t my-first-cloud-app .`
2. Run the docker image with `docker run -p 8080:8080 my-first-cloud-app`
3. In Postman or web browser, go to http://localhost:8080
4. Enjoy!
